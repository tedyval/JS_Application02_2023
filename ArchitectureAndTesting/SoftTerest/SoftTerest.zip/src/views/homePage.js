

let divHome = document.getElementById('homePage');

export async function showHomePage(context){
    context.showSection(divHome);
    
}

